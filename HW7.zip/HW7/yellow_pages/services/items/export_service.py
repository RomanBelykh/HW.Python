from models.item import Item

class ExportItemsService:
  def __init__(self, filename):
    self.filename = filename


  def run(self):
    # TODO: формирование файла с json
    pass
