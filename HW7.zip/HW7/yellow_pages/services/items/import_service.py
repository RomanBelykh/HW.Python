from models.item import Item

class ImportItemsService:
  def __init__(self, filename):
    self.filename = filename


  def run(self):
    # TODO: чтение файла с json
    pass
